# all files used for configuration of application

import os


class Config:
    SECRET_KEY = "secret-string"
    SQLALCHEMY_DATABASE_URI = "private-db-key"
